# Package_simples

Criação de Pacotes Simples; da plataforma [DIO - Digital Innovation One](https://web.dio.me/). 

Descrição: 
O pacote '**processamento_de_imagem**' pode ser usado para:
* Testar conhecimento adquiridos no curso de Python para Cientistas de dados da Dio
	
	


	

## Instalação

Use o gerenciador de pacotes  [pip](https://pip.pypa.io/en/stable/) para instalação do pacote pacote_simples

```bash
pip install simples
```



## Author
Donizete

## License
[MIT](https://choosealicense.com/licenses/mit/)
